@echo off
rem Rudy - Dota Chaos: uninstaller. Settings and stats (%APPDATA%\RudyDotaChaos) are kept unless you answer y.
setlocal
set "RUDY_SELF=%~f0"
fltmc >nul 2>&1
if errorlevel 1 goto :elevate
goto :run

:elevate
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath $env:ComSpec -ArgumentList ('/c ' + [char]34 + [char]34 + $env:RUDY_SELF + [char]34 + [char]34) -Verb RunAs"
exit /b

:run
set "SRC=%~dp0"
if "%SRC:~-1%"=="\" set "SRC=%SRC:~0,-1%"
echo Removing Rudy - Dota Chaos ...
taskkill /f /im RudyDotaChaos.exe >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -Command "foreach($p in @([Environment]::GetFolderPath('CommonDesktopDirectory'),[Environment]::GetFolderPath('CommonPrograms'))){Remove-Item -LiteralPath (Join-Path $p 'Rudy Dota Chaos.lnk') -Force -ErrorAction SilentlyContinue}"
reg delete "HKLM\Software\Microsoft\Windows\CurrentVersion\Uninstall\RudyDotaChaos" /f >nul 2>&1
set "ANS=N"
set /p ANS=Also delete settings and stats? (y/N): 
if /i "%ANS%"=="y" rmdir /s /q "%APPDATA%\RudyDotaChaos"
> "%TEMP%\rudy_rm.bat" echo @echo off
>> "%TEMP%\rudy_rm.bat" echo ping 127.0.0.1 -n 3 ^>nul
>> "%TEMP%\rudy_rm.bat" echo rmdir /s /q "%SRC%"
>> "%TEMP%\rudy_rm.bat" echo del "%%~f0"
start "" /min cmd /c "%TEMP%\rudy_rm.bat"
exit /b 0
