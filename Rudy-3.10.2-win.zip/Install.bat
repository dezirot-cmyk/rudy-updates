@echo off
rem Rudy - Dota Chaos: installer for the EXE build. Double-click, press Yes in the Windows prompt.
rem Installs to Program Files\Rudy. Settings and stats live in %APPDATA%\RudyDotaChaos and are kept.
setlocal
set "RUDY_SELF=%~f0"
fltmc >nul 2>&1
if errorlevel 1 goto :elevate
goto :run

:elevate
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath $env:ComSpec -ArgumentList ('/c ' + [char]34 + [char]34 + $env:RUDY_SELF + [char]34 + [char]34) -Verb RunAs"
exit /b

:run
set "SRC=%~dp0"
if "%SRC:~-1%"=="\" set "SRC=%SRC:~0,-1%"
set "DEST=%ProgramFiles%\Rudy"
set "VER=?"
if exist "%SRC%\version.txt" set /p VER=<"%SRC%\version.txt"
if not exist "%SRC%\RudyDotaChaos.exe" (
    echo RudyDotaChaos.exe not found next to Install.bat. Unzip the archive fully first.
    pause
    exit /b 1
)
echo Installing Rudy - Dota Chaos %VER% ...
taskkill /f /im RudyDotaChaos.exe >nul 2>&1
rem Leftovers of the old Python-based version
if exist "%DEST%\.venv" rd /s /q "%DEST%\.venv"
if exist "%DEST%\rudy" rd /s /q "%DEST%\rudy"
if exist "%DEST%\main.py" del /q "%DEST%\main.py"
if exist "%DEST%\run.bat" del /q "%DEST%\run.bat"
if exist "%DEST%\install.bat" del /q "%DEST%\install.bat"
if not exist "%DEST%" mkdir "%DEST%"
robocopy "%SRC%" "%DEST%" /E /IS /IT /R:3 /W:1 /NFL /NDL /NJH /NJS >nul
if errorlevel 8 (
    echo Copy failed.
    pause
    exit /b 1
)
set "EXE=%DEST%\RudyDotaChaos.exe"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws=New-Object -ComObject WScript.Shell; foreach($p in @([Environment]::GetFolderPath('CommonDesktopDirectory'),[Environment]::GetFolderPath('CommonPrograms'))){ $l=$ws.CreateShortcut((Join-Path $p 'Rudy Dota Chaos.lnk')); $l.TargetPath=$env:EXE; $l.WorkingDirectory=$env:DEST; $l.IconLocation=$env:EXE+',0'; $l.Description='Rudy - Dota Chaos'; $l.Save() }"
set "KEY=HKLM\Software\Microsoft\Windows\CurrentVersion\Uninstall\RudyDotaChaos"
reg add "%KEY%" /v DisplayName /d "Rudy - Dota Chaos" /f >nul
reg add "%KEY%" /v DisplayVersion /d "%VER%" /f >nul
reg add "%KEY%" /v Publisher /d "Rudy" /f >nul
reg add "%KEY%" /v InstallLocation /d "%DEST%" /f >nul
reg add "%KEY%" /v DisplayIcon /d "%EXE%" /f >nul
reg add "%KEY%" /v UninstallString /d "\"%DEST%\Uninstall.bat\"" /f >nul
reg add "%KEY%" /v NoModify /t REG_DWORD /d 1 /f >nul
reg add "%KEY%" /v NoRepair /t REG_DWORD /d 1 /f >nul
echo Done. Starting Rudy ...
explorer.exe "%PUBLIC%\Desktop\Rudy Dota Chaos.lnk"
exit /b 0
